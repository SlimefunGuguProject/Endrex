# Endrex
This is a Slimefun addon, that makes "The End" world less boring. You can explore this world, find some
wild purple trees, or just came here with GEO Miner to gather resources.

## Builds
You can now download releases on [this](https://github.com/nahkd123/Endrex/releases) page.

## Build it yourself
Endrex uses Maven to build, so you'll need Maven

```
cd Endrex
mvn package
cd target
cp "Endrex v1.1.0.jar" "../../testServer/plugins"
```
